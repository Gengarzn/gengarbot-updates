module.exports = {
  nome: "ping",
  aliases: [],
  descricao: "Testa se o bot está vivo",

  async executar({ responder }) {
    await responder("👻 Pong! Estou aqui nas sombras 💜");
  }
};
