module.exports = {
  nome: "sobre",
  aliases: ["info"],
  descricao: "Mostra informações do bot",

  async executar({ responder, config }) {
    await responder(
`👻 *${config.nomeBot}* 💜

꒰ 💜 Versão: ${config.versao}
꒰ 💜 Dono: ${config.nomeDono}
꒰ 💜 Prefixo: ${config.prefixo}

🔮 Feito nas sombras, com carinho.`
    );
  }
};
