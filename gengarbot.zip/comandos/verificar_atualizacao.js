const { buscarAtualizacao } = require("../utils/atualizador");

module.exports = {
  nome: "verificar_atualizacao",
  aliases: ["verificarupdate"],
  descricao: "Verifica se há atualização do bot",

  async executar({ responder, config, ehDono }) {
    if (!ehDono) {
      return responder("👻 Só o dono do bot pode verificar atualizações.");
    }

    await responder("🔮 Procurando atualizações nas sombras...");

    try {
      const info = await buscarAtualizacao();

      if (!info.temAtualizacao) {
        return responder(
`👻 ${config.nomeBot} já está na versão mais nova! 💜

꒰ 💜 Versão atual: ${info.atual}`
        );
      }

      const lista =
        info.novidades.map((n) => `꒰ 🔮 ${n}`).join("\n") ||
        "꒰ 🔮 Melhorias gerais";

      await responder(
`💜 *ATUALIZAÇÃO DISPONÍVEL!* 👻

꒰ 💜 Sua versão: ${info.atual}
꒰ 💜 Nova versão: ${info.nova}

꒰ 🔮 ~~~~ NOVIDADES ~~~~ ꒱
${lista}

Para atualizar, mande: ${config.prefixo}atualizar_bot`
      );
    } catch (e) {
      await responder("❌ Não consegui verificar: " + e.message);
    }
  }
};
