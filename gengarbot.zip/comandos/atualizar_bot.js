const {
  buscarAtualizacao,
  aplicarAtualizacao,
  instalarDependencias
} = require("../utils/atualizador");

module.exports = {
  nome: "atualizar_bot",
  aliases: ["atualizarbot"],
  descricao: "Atualiza o bot para a versão mais nova",

  async executar({ responder, config, ehDono }) {
    if (!ehDono) {
      return responder("👻 Só o dono do bot pode atualizar.");
    }

    try {
      const info = await buscarAtualizacao();

      if (!info.temAtualizacao) {
        return responder(
`👻 ${config.nomeBot} já está atualizado! 💜

꒰ 💜 Versão atual: ${info.atual}`
        );
      }

      await responder(`🔮 Baixando a versão ${info.nova}, aguarde...`);
      const total = await aplicarAtualizacao(info.url);

      await responder("📦 Arquivos atualizados! Instalando dependências...");
      const ok = await instalarDependencias();

      await responder(
`✅ *ATUALIZAÇÃO CONCLUÍDA!* 💜

꒰ 💜 Versão: ${info.atual} ➜ ${info.nova}
꒰ 💜 Arquivos atualizados: ${total}
${ok ? "" : "\n⚠️ Rode `npm install` manualmente depois.\n"}
🔄 Agora reinicie o bot: CTRL + C e depois npm start`
      );
    } catch (e) {
      await responder("❌ Erro ao atualizar: " + e.message);
    }
  }
};
