const modelo = require("../personalizacao/menu");

function saudacao() {
  const hora = Number(
    new Date().toLocaleString("pt-BR", {
      hour: "numeric",
      hour12: false,
      timeZone: "America/Sao_Paulo"
    })
  );
  if (hora < 12) return "Bom dia";
  if (hora < 18) return "Boa tarde";
  return "Boa noite";
}

module.exports = {
  nome: "menu",
  aliases: ["help", "ajuda"],
  descricao: "Mostra este menu",

  async executar({ responder, config, numeroUsuario, listaComandos }) {
    const trocar = (texto) =>
      texto
        .replaceAll("{USUARIO}", numeroUsuario)
        .replaceAll("{DONO}", config.nomeDono)
        .replaceAll("{BOT}", config.nomeBot)
        .replaceAll("{PREFIXO}", config.prefixo)
        .replaceAll("{NUMERO_DONO}", config.numeroDono)
        .replaceAll("{SAUDACAO}", saudacao());

    const itens = listaComandos
      .map((c) =>
        trocar(modelo.item)
          .replaceAll("{COMANDO}", c.nome)
          .replaceAll("{DESCRICAO}", c.descricao || "Sem descrição")
      )
      .join("\n");

    await responder(`${trocar(modelo.topo)}\n${itens}\n${trocar(modelo.rodape)}`);
  }
};
