const readline = require("readline");
const config = require("./config");

// Cores (roxo estilo Gengar)
const R = "\x1b[0m";
const B = "\x1b[1m";
const roxo = "\x1b[38;5;135m";
const roxoEscuro = "\x1b[38;5;93m";
const rosa = "\x1b[38;5;213m";
const cinza = "\x1b[90m";
const verde = "\x1b[38;5;120m";
const vermelho = "\x1b[38;5;203m";
const amarelo = "\x1b[38;5;221m";

const log = {
  info: (t) => console.log(`${roxo}${B} 👻 ${R}${t}`),
  ok: (t) => console.log(`${verde}${B} ✅ ${R}${t}`),
  aviso: (t) => console.log(`${amarelo}${B} ⚠️  ${R}${t}`),
  erro: (t) => console.log(`${vermelho}${B} ❌ ${R}${t}`)
};

function perguntar(texto) {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  return new Promise((resolve) =>
    rl.question(texto, (resp) => {
      rl.close();
      resolve(resp.trim());
    })
  );
}

function banner() {
  console.clear();
  console.log(`
${roxoEscuro}╔══════════════════════════════════════════╗${R}
${roxoEscuro}║${R}  ${roxo}${B}👻  ${config.nomeBot.toUpperCase()}${R}  ${cinza}v${config.versao}${R}
${roxoEscuro}║${R}  ${rosa}🔮  Sombras, sustos e boas conexões${R}
${roxoEscuro}╚══════════════════════════════════════════╝${R}
`);
}

async function painel() {
  while (true) {
    banner();
    console.log(`${roxo}${B}  Como você quer conectar?${R}\n`);
    console.log(`  ${rosa}[1]${R} 📷  Conectar com ${B}QR Code${R}`);
    console.log(`  ${rosa}[2]${R} 🔑  Conectar com ${B}Código de Pareamento${R}\n`);

    const opcao = await perguntar(`${roxo}  ➜ Escolha (1 ou 2): ${R}`);

    if (opcao === "1") {
      log.info("Gerando QR Code, aguarde...");
      return { metodo: "qr" };
    }

    if (opcao === "2") {
      console.log(
        `\n${cinza}  Digite com DDI + DDD, só números. Ex: 5511999999999${R}`
      );
      const numero = (await perguntar(`${roxo}  ➜ Seu número: ${R}`)).replace(/\D/g, "");

      if (numero.length < 10) {
        log.erro("Número inválido. Tente de novo.");
        await new Promise((r) => setTimeout(r, 1500));
        continue;
      }
      log.info("Pedindo o código de pareamento, aguarde...");
      return { metodo: "codigo", numero };
    }

    log.erro("Opção inválida. Digite 1 ou 2.");
    await new Promise((r) => setTimeout(r, 1200));
  }
}

module.exports = { painel, log, cores: { R, B, roxo, rosa, cinza } };
