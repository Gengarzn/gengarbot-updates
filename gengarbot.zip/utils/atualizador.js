const fs = require("fs");
const path = require("path");
const axios = require("axios");
const AdmZip = require("adm-zip");
const { exec } = require("child_process");
const config = require("../config");

const RAIZ = path.resolve(__dirname, "..");

// Itens que NUNCA são substituídos na atualização
const PROTEGIDOS = ["config.js", "sessao", "node_modules", ".env"];

function lerVersaoLocal() {
  try {
    const dados = JSON.parse(
      fs.readFileSync(path.join(RAIZ, "versao.json"), "utf8")
    );
    return dados.versao;
  } catch {
    return config.versao || "0.0.0";
  }
}

// Retorna 1 se a > b, -1 se a < b, 0 se iguais
function compararVersoes(a, b) {
  const pa = String(a).split(".").map(Number);
  const pb = String(b).split(".").map(Number);
  for (let i = 0; i < 3; i++) {
    const x = pa[i] || 0;
    const y = pb[i] || 0;
    if (x > y) return 1;
    if (x < y) return -1;
  }
  return 0;
}

async function buscarAtualizacao() {
  if (!config.urlAtualizacao || config.urlAtualizacao.includes("SEU_LINK")) {
    throw new Error("urlAtualizacao não foi configurada no config.js");
  }

  const resp = await axios.get(config.urlAtualizacao, {
    timeout: 15000,
    params: { t: Date.now() } // evita cache
  });
  const info = typeof resp.data === "string" ? JSON.parse(resp.data) : resp.data;

  if (!info.versao || !info.url) {
    throw new Error("Arquivo de atualização inválido");
  }

  const atual = lerVersaoLocal();
  return {
    atual,
    nova: info.versao,
    novidades: info.novidades || [],
    url: info.url,
    temAtualizacao: compararVersoes(info.versao, atual) > 0
  };
}

async function aplicarAtualizacao(url) {
  const resp = await axios.get(url, {
    responseType: "arraybuffer",
    timeout: 120000,
    maxRedirects: 5
  });

  const zip = new AdmZip(Buffer.from(resp.data));
  const entradas = zip.getEntries().filter((e) => !e.isDirectory);

  // Se o zip veio com tudo dentro de uma pasta única (ex: GitHub), ignora a pasta
  let prefixo = "";
  const pastasTopo = new Set(entradas.map((e) => e.entryName.split("/")[0]));
  const temArquivoNaRaiz = entradas.some((e) => !e.entryName.includes("/"));
  if (!temArquivoNaRaiz && pastasTopo.size === 1) {
    prefixo = [...pastasTopo][0] + "/";
  }

  let total = 0;
  for (const e of entradas) {
    const rel = e.entryName.slice(prefixo.length);
    if (!rel) continue;

    const topo = rel.split("/")[0];
    if (PROTEGIDOS.includes(topo)) continue;

    const destino = path.resolve(RAIZ, rel);
    if (!destino.startsWith(RAIZ + path.sep)) continue; // segurança

    fs.mkdirSync(path.dirname(destino), { recursive: true });
    fs.writeFileSync(destino, e.getData());
    total++;
  }
  return total;
}

function instalarDependencias() {
  return new Promise((resolve) => {
    exec("npm install", { cwd: RAIZ }, (erro) => resolve(!erro));
  });
}

module.exports = {
  buscarAtualizacao,
  aplicarAtualizacao,
  instalarDependencias
};
