const pino = require("pino");
const qrcode = require("qrcode-terminal");
const fs = require("fs");
const path = require("path");
const config = require("./config");
const { painel, log, cores } = require("./config_painelvisual");

let escolha = null; // guarda a escolha do painel

// ===== CARREGAR COMANDOS =====
const comandos = new Map();

function carregarComandos() {
  comandos.clear();
  const pasta = path.join(__dirname, "comandos");
  const arquivos = fs.readdirSync(pasta).filter((f) => f.endsWith(".js"));

  for (const arq of arquivos) {
    try {
      const caminho = path.join(pasta, arq);
      delete require.cache[require.resolve(caminho)];
      const cmd = require(caminho);
      comandos.set(cmd.nome, cmd);
      (cmd.aliases || []).forEach((a) => comandos.set(a, cmd));
    } catch (e) {
      log.erro(`Falha ao carregar ${arq}: ${e.message}`);
    }
  }
  log.ok(`${new Set(comandos.values()).size} comandos carregados`);
}

// ===== TRATAR MENSAGENS =====
function pegarTexto(msg) {
  const m = msg.message || {};
  return (
    m.conversation ||
    m.extendedTextMessage?.text ||
    m.imageMessage?.caption ||
    m.videoMessage?.caption ||
    ""
  );
}

async function tratarMensagem(sock, msg) {
  if (!msg.message || msg.key.remoteJid === "status@broadcast") return;

  const texto = pegarTexto(msg).trim();
  if (!texto.startsWith(config.prefixo)) return;

  const args = texto.slice(config.prefixo.length).split(/\s+/);
  const nomeComando = args.shift().toLowerCase();
  const cmd = comandos.get(nomeComando);
  if (!cmd) return;

  const from = msg.key.remoteJid;
  const remetente = msg.key.participantAlt || msg.key.participant || from;
  const numeroUsuario = remetente.split("@")[0].split(":")[0];
  const ehDono = msg.key.fromMe || numeroUsuario === config.numeroDono;

  const responder = (textoResp) =>
    sock.sendMessage(
      from,
      { text: textoResp, mentions: [remetente] },
      { quoted: msg }
    );

  try {
    await cmd.executar({
      sock,
      msg,
      from,
      args,
      config,
      numeroUsuario,
      ehDono,
      responder,
      listaComandos: [...new Set(comandos.values())]
    });
  } catch (e) {
    log.erro(`Erro no comando ${nomeComando}: ${e.message}`);
    await responder("👻 Algo deu errado nas sombras...");
  }
}

// ===== CONEXÃO =====
async function conectar() {
  // O Baileys 7 é ESM, por isso o import dinâmico
  const baileys = await import("@whiskeysockets/baileys");
  const makeWASocket = baileys.default;
  const {
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    Browsers
  } = baileys;

  const { state, saveCreds } = await useMultiFileAuthState("sessao");
  const { version } = await fetchLatestBaileysVersion();

  // Só mostra o painel se ainda não estiver conectado
  if (!state.creds.registered && !escolha) {
    escolha = await painel();
  }

  const sock = makeWASocket({
    version,
    logger: pino({ level: "silent" }),
    auth: state,
    browser: Browsers.ubuntu("Chrome"),
    markOnlineOnConnect: false
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type !== "notify") return;
    for (const msg of messages) {
      try {
        await tratarMensagem(sock, msg);
      } catch (e) {
        log.erro("Erro ao tratar mensagem: " + e.message);
      }
    }
  });

  let codigoPedido = false;

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect, qr } = update;

    // WhatsApp está pronto para parear
    if (qr && escolha) {
      if (escolha.metodo === "codigo") {
        if (codigoPedido) return;
        codigoPedido = true;
        try {
          const codigo = await sock.requestPairingCode(escolha.numero);
          const formatado = codigo.match(/.{1,4}/g).join("-");
          console.log(`\n${cores.roxo}${cores.B}  🔑 SEU CÓDIGO: ${cores.rosa}${formatado}${cores.R}\n`);
          log.info("WhatsApp > Aparelhos conectados > Conectar com número de telefone.");
        } catch (e) {
          log.erro("Não consegui gerar o código: " + e.message);
        }
      } else {
        console.log("");
        qrcode.generate(qr, { small: true });
        log.info("WhatsApp > Aparelhos conectados > Conectar aparelho.");
      }
    }

    if (connection === "open") {
      log.ok(`${config.nomeBot} conectado com sucesso! 💜`);
    }

    if (connection === "close") {
      const codigo = lastDisconnect?.error?.output?.statusCode;
      if (codigo === DisconnectReason.loggedOut) {
        log.erro("Sessão encerrada. Apague a pasta 'sessao' e ligue de novo.");
        process.exit(0);
      } else {
        log.aviso("Conexão caiu. Reconectando...");
        conectar();
      }
    }
  });
}

carregarComandos();
conectar().catch((e) => log.erro("Erro fatal: " + e.message));
