module.exports = {
  // Variáveis: {USUARIO} {DONO} {BOT} {PREFIXO} {NUMERO_DONO} {SAUDACAO}
  topo:
`👻 {SAUDACAO}, @{USUARIO}! Meu menu sombrio chegou 💜

꒰ 🔮 ~~~~ 💜 DETALHES 💜 ~~~~ ꒱
꒰ 💜 Usuário: @{USUARIO}
꒰ 💜 Dono: {DONO}
꒰ 💜 Bot: {BOT}
꒰ 💜 Prefixo: {PREFIXO}
꒰ 💜 Número dono: {NUMERO_DONO}

꒰ 🔮 ~~~~ 👻 COMANDOS 👻 ~~~~ ꒱`,

  // Como cada comando aparece na lista
  item: "꒰ 🔮 {PREFIXO}{COMANDO} ➜ {DESCRICAO}",

  rodape: "\n👻 {BOT} • Te vejo nas sombras 💜"
};
